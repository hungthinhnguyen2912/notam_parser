from setuptools import setup,find_packages

setup(
    name='parser_notam_package',
    version='0.1',
)