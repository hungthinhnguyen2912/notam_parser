from importlib_metadata import entry_points
from setuptools import setup,find_packages

setup(
    name='parser_notam_package',
    version='0.2',
    packages=find_packages(),
    entry_points= {

    }
)